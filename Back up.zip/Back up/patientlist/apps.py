from django.apps import AppConfig


class PatientslistConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'patientslist'

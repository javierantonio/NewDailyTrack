from django.apps import AppConfig


class SpecialistcalendarConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'specialistcalendar'

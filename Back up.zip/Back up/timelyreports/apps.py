from django.apps import AppConfig


class TimelyreportsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'timelyreports'
